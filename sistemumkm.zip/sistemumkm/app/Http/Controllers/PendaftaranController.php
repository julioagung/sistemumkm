<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pendaftaran;

class PendaftaranController extends Controller
{
    public function index()
    {
        return view('pendaftaran'); // Mengarahkan ke view pendaftaran
    }
    public function store(Request $request)
{
    // Validasi data
    $validated = $request->validate([
        'nama' => 'required',
        'alamat' => 'required',
        'email' => 'required|email|unique:pendaftarans',
        'telepon' => 'required',
    ]);

    // Simpan ke database
    Pendaftaran::create($validated);

    return "Pendaftaran berhasil!";
}
}
