<?php

namespace App\Http\Controllers;

use App\Models\UMKM;
use Illuminate\Http\Request;
use GuzzleHttp\Client;

class UMKMController extends Controller
{
    public function index()
    {
        // Mengambil data UMKM dari database
        // Ambil semua data UMKM dari database
    $umkms = UMKM::all();

    // Kirim data ke view
    return view('informasi', compact('umkms'));
    }
    public function getUMKMFromAPI()
    {
    $client = new Client();
    $response = $client->get('URL_API_UMKM'); // Ganti dengan URL API yang sesuai

    $umkms = json_decode($response->getBody()->getContents(), true);

    return view('informasi', compact('umkms'));
    }
    public function informasi() {
        return view('informasi', [
            'umkms' => [
                ['nama' => 'UMKM A', 'lokasi' => 'Jambi', 'deskripsi' => 'Deskripsi UMKM A'],
                ['nama' => 'UMKM B', 'lokasi' => 'Palembang', 'deskripsi' => 'Deskripsi UMKM B'],
            ]
        ]);
    }
    
}
