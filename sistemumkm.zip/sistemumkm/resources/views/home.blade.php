<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website UMKM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <header class="text-center">
            <h1>Selamat Datang di Website UMKM!</h1>
            <p>Website untuk mendaftar dan mempromosikan UMKM Anda</p>
            <!-- Menambahkan tombol Login -->
            <a href="{{ url('/login') }}" class="btn btn-primary btn-lg">Login Admin</a>
        </header>

        <section class="mt-5">
    <h2 class="text-center">Layanan Kami</h2>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <img src="https://cdn.gencraft.com/prod/user/1202e292-e1fd-40c0-acc8-d1a13ca963e6/a7de60be-25c8-43d5-a776-a8884eb34b43/image/image0_0.jpg?Expires=1734454241&Signature=TiRL8ZW6iePJljBPuB3X9bKOf20MUBtLyswFLrxzt2~LHqMZj-zu-bfPo4FreKwk3F4CEC55XB1NM1rMn5Pftdk0E4OkaCjaqmRELWJdjNJJxN8hnBG-0ym8ymlma8Kf8PQoFuj5XOf3eHfxcxxUaHVfHgvCUvtZZqxangVXeiXkSjDaHvqtHhz9NvWJFaBLR6NcqJh41gT-W3H8pXcbZWukEdeqwM1uroHmWyhtsJpCVdwy3Uy-T~RTHnv8VZf8jnQA1NVfz83Nf7ILegGdGnowXJ-wN-HbAZaFcJTwXL-jRGHmRwboZXQAgPv5W7TYrS8j5LSNaAe570fn6W~NCw__&Key-Pair-Id=K3RDDB1TZ8BHT8">
                <div class="card-body">
                    <h5 class="card-title">Pendaftaran UMKM</h5>
                    <p class="card-text">Daftarkan UMKM Anda dengan mudah di website kami.</p>
                    <a href="{{ url('/pendaftaran') }}" class="btn btn-primary">Daftar Sekarang</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://cdn.gencraft.com/prod/user/1202e292-e1fd-40c0-acc8-d1a13ca963e6/e652a1e7-d264-4e03-932d-acec54c7f635/image/image1_0.jpg?Expires=1734453908&Signature=knq0El8tPkbWAM03LLqMuB~YWv1vRndhGcKqvHrvs4jjDwXeMPKr79dtgV7CE2fgU1eVOQ5Hr20UrELMszeEQtHCHIhJgLttDbXkarSJ600ybhG4xho7CZwx4PUvSMMtx5P2Dtak8tzhcI2xIi8L2RUuHMpGkEnpm2g7xkkOFQfnlDaXaX3QB0n1n6A75Nnz2SVf8GEXWufvA~E5-4864zbgieU33IyURWjh0RLWA~Vj1iFBTvKfg-HuKeNaSGl0B9rg6b12onJMauQZWW4~eYZv0SUZ7QFv5yiliUAP3dDGybiKvdk19spRAt3U9oXBjXAEPdTnwuTuxnLchg9pgw__&Key-Pair-Id=K3RDDB1TZ8BHT8" class="card-img-top custom-img-size" alt="Layanan 2">
                <div class="card-body">
                    <h5 class="card-title">Informasi UMKM</h5>
                    <p class="card-text">Temukan informasi UMKM di seluruh Indonesia.</p>
                    <a href="{{ url('/informasi-umkm') }}" class="btn btn-primary">Daftar Sekarang</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="https://cdn.gencraft.com/prod/user/1202e292-e1fd-40c0-acc8-d1a13ca963e6/63540c7d-51f7-452f-9800-f57cf304d3fd/image/image1_0.jpg?Expires=1734454049&Signature=OLiqyJ-7NfaxRC7SRjJ622CFon9ZhqM1S09o6ZgSez9cdvGHvhYfynMqvTINzy6W5XFOQjvpApIDvVZj8MxKKDsJxi0sMLSYUUHBJ7qBoSfFdOUosquxq8ywOQ7xwAgyxUpWVV-1aGTBSfTAecdcoWq-kEqWyABy5xa48RFjJqNzrEJUiQDbYMCfw8NEcFc-381Ah4t6wWh9uQsExyhwVvmlT9oYv9isN1gR6t9SbnLFVCFNNfLkGXkxA64odPOeBzNyXJfGMu1UL-Q2ML9VCccbKc4yna2Jxgg6omWvLLFmr2wFKqoLYcZ8FIOfVcC5DvTWgKPB6zumPyszAxQZbw__&Key-Pair-Id=K3RDDB1TZ8BHT8" class="card-img-top custom-img-size" alt="Layanan 3">
                <div class="card-body">
                    <h5 class="card-title">Promo & Diskon</h5>
                    <p class="card-text">Dapatkan promo dan diskon menarik dari UMKM kami.</p>
                    <a href="{{ url('/promo-diskon') }}" class="btn btn-primary">Lihat Promo</a>
                </div>
            </div>
        </div>
    </div>
</section>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
<footer class="text-center mt-5">
    <p>&copy; 2024 Website UMKM. <a href="{{ url('/login') }}">Login Admin</a></p>
</footer>


</html>
