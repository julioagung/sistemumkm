<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi UMKM</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1 class="text-center mb-4">Informasi UMKM di Indonesia</h1>
        <div class="row">
            <!-- UMKM A -->
            <div class="col-md-6 mb-4">
                <div class="card h-100 shadow-sm">
                    <img src="https://dprd-jambiprov.go.id/foto_berita/2023/03/26/42.jpg" class="card-img-top" alt="UMKM A">
                    <div class="card-body">
                        <h5 class="card-title">UMKM A</h5>
                        <p class="card-text"><strong>Lokasi:</strong> Jambi</p>
                        <p class="card-text">UMKM A adalah penyedia layanan makanan sehat dengan kualitas premium.</p>
                    </div>
                    <div class="card-footer text-center">
                        <a href="https://ruangdata.jambikota.go.id/data-pembangunan/koperasi-usaha-kecil-dan-menengah" class="btn btn-primary btn-sm">Lihat Detail</a>
                    </div>
                </div>
            </div>
            <!-- UMKM B -->
            <div class="col-md-6 mb-4">
                <div class="card h-100 shadow-sm">
                    <img src="https://cdn.antaranews.com/cache/1200x800/2022/10/28/UMKM-906.jpg.webp" class="card-img-top" alt="UMKM B">
                    <div class="card-body">
                        <h5 class="card-title">UMKM B</h5>
                        <p class="card-text"><strong>Lokasi:</strong> Palembang</p>
                        <p class="card-text">UMKM B fokus pada produk kerajinan tangan ramah lingkungan.</p>
                    </div>
                    <div class="card-footer text-center">
                        <a href="https://diskopukm.palembang.go.id/" class="btn btn-primary btn-sm">Lihat Detail</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
