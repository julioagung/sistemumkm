<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PendaftaranController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// Halaman Utama
Route::get('/promo-diskon', function () {
    return view('promo-diskon'); // Mengarah ke view promo-diskon.blade.php
});
Route::get('/', function () {
    return view('home'); // Mengakses halaman utama
});

// Halaman Pendaftaran
Route::get('/pendaftaran', function () {
    return view('pendaftaran'); // Mengakses halaman pendaftaran
});

// Halaman Login Admin
Route::get('/login', function () {
    return view('login'); // Mengakses halaman login
});
// Route untuk handle pendaftaran
Route::post('/pendaftaran', [PendaftaranController::class, 'store'])->name('pendaftaran.submit');
// Route untuk handle login
Route::post('/login', [LoginController::class, 'authenticate'])->name('login.submit');
Route::get('/informasi-umkm', [UMKMController::class, 'showUMKM']);
Route::get('/informasi-umkm', [UMKMController::class, 'getUMKMFromAPI']);
Route::get('/informasi-umkm', [App\Http\Controllers\UMKMController::class, 'informasi'])->name('informasi.umkm');




