<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promo & Diskon</title>
    <!-- Tambahkan Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">UMKM Kita</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Promo & Diskon</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Banner -->
    <div class="jumbotron text-center bg-primary text-white py-5">
        <h1 class="display-4">Promo & Diskon UMKM</h1>
        <p class="lead">Temukan penawaran menarik untuk mendukung UMKM Indonesia!</p>
    </div>

    <!-- Promo & Diskon -->
    <div class="container mt-5">
        <div class="row g-4">
            <!-- Promo 1 -->
            <div class="col-md-4">
                <div class="card h-100">
                    <img src="https://sibakuljogja.jogjaprov.go.id/blog/pasarkotagedeyia/wp-content/uploads/sites/112/2024/09/promo-diskon.jpg" class="card-img-top" alt="Promo 1">
                    <div class="card-body">
                        <h5 class="card-title">Diskon 20% Produk Kerajinan</h5>
                        <p class="card-text">Dapatkan diskon untuk berbagai produk kerajinan lokal dari UMKM terbaik.</p>
                        <a href="https://sibakuljogja.jogjaprov.go.id/blog/pasarkotagedeyia/diskon-besar-besaran-di-galeri-pasar-kotagede-yia-kesempatan-belanja-hemat-selama-bulan-september/" class="btn btn-primary">Lihat Selengkapnya</a>
                    </div>
                </div>
            </div>

            <!-- Promo 2 -->
            <div class="col-md-4">
                <div class="card h-100">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxd96VgUoSVs6Yec0KRbiKV6a2L1h7yVx3PA&s" class="card-img-top" alt="Promo 2">
                    <div class="card-body">
                        <h5 class="card-title">Buy 1 Get 1 Gratis</h5>
                        <p class="card-text">Nikmati penawaran beli satu gratis satu untuk produk makanan dan minuman lokal.</p>
                        <a href="https://www.instagram.com/yukpromomakassar/p/DApNpqvzpYw/" class="btn btn-primary">Lihat Selengkapnya</a>
                    </div>
                </div>
            </div>

            <!-- Promo 3 -->
            <div class="col-md-4">
                <div class="card h-100">
                    <img src="https://www.jakmall.com/images/desktop/event/2019/12/harbolnas-produk-lokal/main-koleksi-karya-bangsa-m.png?1" class="card-img-top" alt="Promo 3">
                    <div class="card-body">
                        <h5 class="card-title">Diskon Spesial Akhir Tahun</h5>
                        <p class="card-text">Jangan lewatkan diskon besar-besaran dari UMKM menjelang akhir tahun ini!</p>
                        <a href="https://www.jakmall.com/harbolnas-produk-lokal" class="btn btn-primary">Lihat Selengkapnya</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-light text-center text-lg-start mt-5">
        <div class="text-center p-3">
            © 2024 UMKM Kita. Semua Hak Dilindungi.
        </div>
    </footer>

    <!-- Tambahkan Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\sistemumkm\resources\views/promo-diskon.blade.php ENDPATH**/ ?>